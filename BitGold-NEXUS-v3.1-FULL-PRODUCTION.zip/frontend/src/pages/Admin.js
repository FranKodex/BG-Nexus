
export default function Admin(){
  return (
    <div style={{background:'#0f172a', color:'#fff', minHeight:'100vh'}}>
      <h1>Admin Panel</h1>
      <p>User Management • KYC • Cards • Loans • Feature Flags</p>
    </div>
  );
}
