
module.exports = [
  "BitGold Regular",
  "BitGold Pro",
  "BitGold Captain",
  "BitGold VIP",
  "BitGold Shareholder"
];
