
require("dotenv").config();
const express = require("express");
const app = express();
app.use(express.json());

app.use("/api/auth", require("./src/routes/auth"));
app.use("/api/admin", require("./src/routes/admin"));
app.use("/api/kyc", require("./src/routes/kyc"));
app.use("/api/wallets", require("./src/routes/wallets"));
app.use("/api/cards", require("./src/routes/cards"));
app.use("/api/loans", require("./src/routes/loans"));
app.use("/api/audit", require("./src/routes/audit"));

app.listen(5000, () => console.log("BitGold-NEXUS v3.1 API running"));
