
# BitGold-NEXUS v3.1 – FULL PRODUCTION EDITION

Includes:
- Full Backend API (Auth, Admin, KYC, Wallets, Cards, Loans)
- Full Frontend (User + Admin, Dark Mode)
- WalletConnect Integration
- Investor Ranking Badges
- Audit Logs
- Feature Flags
- Email Notifications
- Docker + One-click Deploy

Ready for cloud deployment.
